import React from 'react';
import { FEATURES } from '../constants';

const FeatureList: React.FC = () => {
  return (
    <div className="space-y-4">
        {FEATURES.map((feature) => (
            <div 
                key={feature.id} 
                className="glass-card rounded-2xl p-5 relative overflow-hidden group hover:border-primary/50 transition-all duration-300"
            >
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity pointer-events-none">
                    <span className="material-icons-round text-6xl text-primary select-none">{feature.largeIcon}</span>
                </div>
                <div className="flex items-start gap-4">
                    <div className={`bg-gradient-to-br ${feature.gradient} p-3 rounded-xl shadow-lg ${feature.shadow}`}>
                        <span className="material-icons-round text-white text-xl">{feature.icon}</span>
                    </div>
                    <div className="z-10">
                        <h4 className="font-bold text-lg mb-1">{feature.title}</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                            {feature.description}
                        </p>
                    </div>
                </div>
            </div>
        ))}
    </div>
  );
};

export default FeatureList;