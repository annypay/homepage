import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="flex justify-between items-center mb-12">
      <div className="flex items-center gap-2">
        <span className="material-icons-round text-primary text-3xl glow-icon select-none">api</span>
        <span className="font-display font-bold text-lg tracking-wider text-slate-900 dark:text-white select-none">
          LINGXI
        </span>
      </div>
      <button 
        className="glass-card p-2 rounded-full text-slate-600 dark:text-slate-300 hover:text-primary transition-colors cursor-pointer"
        aria-label="Menu"
      >
        <span className="material-icons-round">menu</span>
      </button>
    </header>
  );
};

export default Header;