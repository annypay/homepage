import React from 'react';
import { BarChart, Bar, ResponsiveContainer, Cell } from 'recharts';
import { CHART_DATA } from '../constants';

const MarketTrend: React.FC = () => {
  return (
    <div className="glass-card rounded-2xl p-4 mt-4">
      <div className="flex justify-between items-center mb-2">
        <span className="text-xs font-semibold text-primary uppercase tracking-wider">Market Trend</span>
        <span className="text-[10px] text-slate-400">Live Data</span>
      </div>
      <div className="h-24 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={CHART_DATA}>
            <Bar dataKey="value" radius={[4, 4, 0, 0]}>
              {CHART_DATA.map((entry, index) => {
                // Emulate the visual style: last items are more intense/teal
                // Using opacity or different colors to create the gradient effect across bars
                const isLast = index === CHART_DATA.length - 1;
                const isSecondLast = index === CHART_DATA.length - 2;
                
                let fill = '#cbd5e1'; // slate-300 (default light)
                
                // Dark mode awareness hack: Recharts doesn't strictly support CSS var reading easily without hooks,
                // but we can use Tailwind hex codes. 
                // Primary Teal: #2dd4bf
                
                if (isLast) fill = '#0d9488'; // teal-600
                else if (isSecondLast) fill = '#2dd4bf'; // teal-400
                else fill = `rgba(45, 212, 191, ${0.3 + (index * 0.1)})`; // Fade in teal
                
                return <Cell key={`cell-${index}`} fill={fill} />;
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default MarketTrend;