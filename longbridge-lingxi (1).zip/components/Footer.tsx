import React from 'react';
import { SOCIALS } from '../constants';

const Footer: React.FC = () => {
  return (
    <section className="mt-auto pt-8 pb-4">
      <div className="flex items-center gap-2 mb-6 justify-end">
        <h3 className="font-display text-xl font-bold text-right">关注我们</h3>
        <div className="h-8 w-1 bg-primary rounded-full glow-icon"></div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        {/* Blog Link - Full Width */}
        <a 
          className="col-span-2 glass-card rounded-xl p-4 flex items-center justify-between group hover:bg-white/90 dark:hover:bg-slate-700 transition-all cursor-pointer" 
          href="#"
        >
          <div className="flex items-center gap-3">
            <span className="material-icons-round text-primary">rss_feed</span>
            <span className="font-medium">灵犀博客 (Blog)</span>
          </div>
          <span className="material-icons-round text-slate-400 group-hover:translate-x-1 transition-transform">arrow_forward</span>
        </a>

        {/* SVG Socials */}
        {SOCIALS.map((social) => (
          <a 
            key={social.name}
            className={`glass-card rounded-xl p-4 flex flex-col items-center justify-center gap-2 dark:hover:bg-slate-800 transition-colors group cursor-pointer ${social.colorClass}`} 
            href={social.href}
          >
             {social.svgPath && (
                <svg className="w-6 h-6 fill-current group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                    <path d={social.svgPath}></path>
                </svg>
             )}
            <span className="text-xs font-medium">{social.name}</span>
          </a>
        ))}

        {/* WeChat Link */}
         <a 
            className="col-span-2 glass-card rounded-xl p-4 flex items-center justify-center gap-2 hover:bg-green-50 dark:hover:bg-slate-800 transition-colors group cursor-pointer" 
            href="#"
        >
            <span className="material-icons-round text-green-500 group-hover:scale-110 transition-transform">chat_bubble</span>
            <span className="text-sm font-medium">WeChat Official</span>
        </a>
      </div>

      <footer className="mt-8 text-center border-t border-slate-200 dark:border-slate-800 pt-6">
        <p className="text-[10px] text-slate-400 dark:text-slate-500">
            Copyright © 2024-2025 长桥灵犀 - sevenfication. All rights reserved.
        </p>
     </footer>
    </section>
  );
};

export default Footer;