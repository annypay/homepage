import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="mb-12">
      <div className="flex flex-col items-start space-y-2 mb-6">
        <h1 className="font-display text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-600 to-blue-600 dark:from-teal-300 dark:to-teal-500 pb-2">
          长桥灵犀
        </h1>
        <h2 className="font-display text-2xl font-light tracking-[0.2em] text-slate-600 dark:text-slate-400">
          「专注交易」
        </h2>
      </div>
      <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-300 backdrop-blur-sm rounded-lg">
        Crypto 高级量化分析及数据分析，帮助您在加密货币市场中找到最佳交易时机。结合动态指标、实时数据和市场趋势，确保高效应对快速变化的环境。
      </p>
    </section>
  );
};

export default Hero;