import React from 'react';

const Background: React.FC = () => {
    return (
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
            {/* Light Mode Blobs */}
            <div className="absolute border-radius-50 filter blur-[80px] z-0 opacity-60 bg-teal-200/40 w-96 h-96 -top-20 -left-20 dark:hidden animate-blob"></div>
            <div className="absolute border-radius-50 filter blur-[80px] z-0 opacity-60 bg-blue-200/40 w-80 h-80 top-40 right-0 dark:hidden animate-blob" style={{ animationDelay: "2s" }}></div>
            
            {/* Dark Mode Blobs */}
            <div className="absolute border-radius-50 filter blur-[80px] z-0 opacity-60 bg-primary/20 w-[500px] h-[500px] -top-32 -left-32 hidden dark:block animate-blob"></div>
            <div className="absolute border-radius-50 filter blur-[80px] z-0 opacity-60 bg-blue-900/40 w-[400px] h-[400px] bottom-0 right-0 hidden dark:block animate-blob" style={{ animationDelay: "4s" }}></div>
            
            {/* Forest Pattern Overlay */}
            <div className="absolute inset-0 bg-forest-pattern opacity-100 dark:opacity-80"></div>
        </div>
    );
};

export default Background;